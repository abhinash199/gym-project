import axios from 'axios';
import React,{useEffect, useState} from 'react'
import { useParams } from 'react-router';
const MEMBERS_DETAILS_API = "http://localhost:4001/membersdetail";
function MemberDetail(props) {
    const[member,setmember]= useState([]);
    const [newmember,setnewmember]=useState();
    const uid=useParams();
    console.log(uid);
    console.log("props",props);
  
       
    useEffect(() => {
        fetch(
            `${MEMBERS_DETAILS_API}?uid=${uid}`,
            {
                method: "GET"
            }
        )
            .then(res => res.json())
            .then(response => {
               setmember(response.data);
            })
            .catch(error => console.log(error));
    }, [uid]);
     const render=(person,index)=>{
         return(
             <>
             <h2>{person.firstname}</h2>
             <h2>{person.lastname}</h2>
             <h2>{person.email}</h2>
             </>
         )
     }
    return (
        <div>
          {
            //   member.data.map((item)=>(
            //       <h2>{item.firtname} {item.lastname}{item.email}</h2>
            //   ))
        //    member.map((item)=>(
        //         <h2>{item.firtname} {item.lastname}{item.email}</h2>
        //     )),
      
            // member.data.map((i)=>(
            //     <h2>{i.firstname}</h2>
            // ))
      console.log(member)
          }
        </div>
    )
}


MemberDetail.getInitialProps = async({req,res,match,history,location,...ctx}) => {
    let result=await axios.get(MEMBERS_DETAILS_API);
    console.log("query",result)
    return {result: result.data}
}

export default MemberDetail

