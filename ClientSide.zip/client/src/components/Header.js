import React,{useContext,useState} from 'react'
import {Navbar,Container,Nav,Button} from "react-bootstrap"
import { useHistory,Link} from "react-router-dom";
import {UserContext} from "../App";
function Header() {
  const initialState = "0px";
  const [navWidth, setnavWidth] = useState(initialState);

  const opennav = () => {
    setnavWidth("250px");
  }
  const closenav = () => {
    setnavWidth("0px");
  }
  const {state,dispatch} = useContext(UserContext);
  const history = useHistory();
  const handleSignup =()=>{
    history.push('/signup')
  }
  const RenderMenu=()=>{
    console.log("state",state)
    if(state){

      return(
        <>
       <Navbar bg="primary" variant="dark" fixed ="top">
        <Container>
           <span className="menulines" onClick={opennav}>&#9776;</span>

          <Link to="/profile">Life City</Link>
          <Nav className="mr-auto">
          <Link to="/profile/room-detail">
            find Room
            </Link>

            <Link to="/add-room">Post room</Link>
            <Link to="/about">About us</Link>
            {/* <Link to="profile/my-account">
            Your Profile
            </Link>
            <Nav.Link href="#pricing">{state.firstname}</Nav.Link> */}
          </Nav>
        </Container>
      

        <Button variant="danger"   onClick={()=>{
              localStorage.clear()
              dispatch({type:"CLEAR"});
              history.push('/');
            }}>Logout</Button>
      
      </Navbar>
      <div className="sidenav" id="mySidenav" style={{ width: `${navWidth}`,transition:"all 0.5s" }}>
        <a href="javascript:void(0)" className="closebtn" onClick={closenav}>&times;</a>
        <a href="#"><h4 className="cricket">Hi,{state.firstname}</h4></a>
        <a href="#">Home</a>
        <Link  onClick={closenav} to="/profile/room-detail">
            find Room
            </Link>

            <Link   onClick={closenav}to="/add-room">Post room</Link>
            <Link   onClick={closenav} to="/about">About us</Link>
       
         <Link   onClick={closenav}to="/profile/my-account">
          My Profile
            </Link>
            {}
            <Link  onClick={closenav} to={'/mypost/' + state._id}>
          Mypost
            </Link>
            <Link  onClick={closenav} onClick={(e)=>{
              e.preventDefault();
              localStorage.clear()
              dispatch({type:"CLEAR"});
              history.push('/');
            }}>
          Logout
            </Link>
       
      </div>
       </>
        
      )
    }else{
      return(
      <>
       <Navbar bg="primary" variant="dark" fixed="top">
        <Container>
          <Navbar.Brand href="/">Life City Colony</Navbar.Brand>
          <Nav className="mr-auto">
            <Nav.Link href="/signin">Post room</Nav.Link>
            <Nav.Link href="/signin">find room</Nav.Link>
            <Nav.Link href="/about">About</Nav.Link>
          </Nav>
        </Container>
       <a href="/signin" style={{color:"white"}}>Login</a>

        <Button variant="danger" onClick={handleSignup}>Signup</Button>
      
      </Navbar>
      
        </>
      )
    }
  }
  
  return (
    <>
     <RenderMenu/>
</>
     
  )
}

export default Header
