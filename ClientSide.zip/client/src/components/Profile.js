import React,{useEffect,useState} from 'react'
import{Navbar,Nav,Container,Button,Carousel,Card,CardGroup} from "react-bootstrap";
const Fetch_API = "http://localhost:4001/profile";
import "./profile.css";
import axios from "axios";
import Home from "./Home";
import MemberDetail from './member-detail';
function Profile() {
    const [datas, setdata] = useState();
   
       
    const gedetail=async()=>{
      try{
         const res=await fetch(Fetch_API,{
             method:"GET",
             headers:{
                 Accept:"application/json",
                 "Content-Type":"application/json"
             }
        
         });
         const data=await res.json();
         setdata(data);
        console.log(data);
      }catch(err){
 console.log(err);
      }
  }
  useEffect(() => {
 //  gedetail();
  }, [])
    return (
       <>
     <Home />
       
       
      
 
       </>
    )
}

export default Profile
