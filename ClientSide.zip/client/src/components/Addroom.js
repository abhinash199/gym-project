import React,{useState,useContext} from 'react'
import "./signup.css";
import { useForm } from "react-hook-form";
import axios from "axios";

import uuid from 'react-uuid';
const POSTROOM_API = "http://localhost:4001/add-room";
const UPLOAD_API = "http://localhost:4001/upload";
import {UserContext} from "../App";
function Addroom() {
   const {state,dispatch} = useContext(UserContext);
    const [selectedFile, setselectedFile] = useState("")
    const { register, handleSubmit, formState: { errors } } = useForm();

    //profile pic 
    const onFileChange = event => {
        const file = event.target.files[0];
        setselectedFile(file);
    };

    const onSubmit = async (data) => {
      const  postedid=state._id;
        console.log("postedid",postedid);
        const { plotno,bhk, price, roomtype,address,status,water,category} = data;
        if (!selectedFile) {
            window.alert("select an image");
        } else {
            let uid = uuid();
            let userImageName = uid + '-' + selectedFile.name;
            var blob = selectedFile.slice(0, selectedFile.size, 'image/png');
            var updatedSelectedFile = new File([blob], userImageName, { type: 'image/png' });
            setselectedFile(updatedSelectedFile);
            const signupData = {
                plotno,
                bhk,
                 price,
                  roomtype,
                  postedid,
                  water,
                  status,
                  category,
                  address,
                     
                imageName: userImageName,
                uid: uid
            }

            let fData = new FormData();
            fData.append('image', updatedSelectedFile);
            console.log(fData);
            const config = {
                headers: {
                    'Content-Type': 'multipart/form-data'

                }
            }

            const signUpConfig = {
                headers: {
                    'Content-Type': 'application/json',
                    "Authorization":"Bearer"+localStorage.getItem("jwt")
                }
            }

            axios.post(
                POSTROOM_API,
                JSON.stringify(signupData),
                signUpConfig
            )
                .then(res => {
                    if (res.status === 200 && res.data && res.data.error) {
                        window.alert("Employee ID is already exist");
                    } else {
                        axios.post(
                            UPLOAD_API,
                            fData,
                            config
                        )
                            .then(res => {
                                window.alert("Save Successfull");
                                console.log("Save Successfull");
                               // router.push('/our-teams');

                            })
                            .catch(err => {
                                console.log(err);
                            })
                    }
                })
                .catch(err => {
                    console.log(err);
                })
        }
    }
  
    return (
        
        <>
        { 
        state?
        
            <div class="limiter">
                <div class="container-login100">
                    <div class="wrap-login100 p-l-50 p-r-50 p-t-77 p-b-30">
                        <form class="login100-form validate-form" onSubmit={handleSubmit(onSubmit)}  encType="multipart/form-data">
                            <span class="login100-form-title p-b-55">
                               Enter detail
                            </span>
                            <label>Enter Plot No.</label><br/>
                            <div className="form-group " id="plotno">
                                <input type="number" className="form-control"
                                    {...register("plotno", { required: "required" })}
                                />

                            </div>
                            <label>Category:</label><br/>
                            <div className="form-group">
                                <select type="select" className="form-control" name="status"
                                                        {...register("category", { required: true })}
                                                   >    
                                                     <option value="">select</option>
                                                        <option value="Apartment">Apartment</option>
                                                        <option value="Building">Building</option>
                                                        <option value="Multi-complex">Multi-complex</option>
                                                        <option value="Row House">Row House</option>
                                                      
                                                  </select>

                            </div>
                            <label>Select room type</label><br/>

                            <div className="form-group ">
                                <select type="select" className="form-control" name="bhk"
                                                        {...register("bhk", { required: true })}
                                                   >
                                                        <option>select</option>
                                                        <option>1BHK</option>
                                                        <option>2BHK</option>
                                                        <option>3BHK</option>
                                                        <option>Single room</option>
                                                        
                                                  </select>

                            </div>
                            
                           
                            <label>current status:</label><br/>
                            <div className="form-group">
                                <select type="select" className="form-control" name="status"
                                                        {...register("status", { required: true })}
                                                   >    
                                                     <option value="">select</option>
                                                        <option value="Available">Available</option>
                                                        <option value="Booked">Booked</option>
                                                      
                                                  </select>

                            </div>
                            <label>Room Condition</label><br/>
                            <div className="form-group">
                                <select type="select" className="form-control" name="roomtype"
                                                        {...register("roomtype", { required: true })}
                                                   >
                                                        <option>select</option>
                                                        <option>New</option>
                                                        <option>0-1 year old</option>
                                                        <option>1-2 year old</option>
                                                        <option>2-3 year old </option>
                                                         <option>more than 3 year old </option>
                                                  </select>

                            </div>
                            
                            <label>Water supply</label><br/>
                            <div className="form-group">
                                <select type="select" className="form-control" name="water"
                                                        {...register("water", { required: true })}
                                                   >
                                                        <option>select</option>
                                                        <option>Borewell</option>
                                                        <option>Tanker</option>
                                                        <option>Other</option>
                                                  </select>

                            </div>
                             <label>Room Price (without electricity)</label><br/>
                            <div className="form-group">
                                <input type="number" className="form-control"
                                    {...register("price", { required: "required" })}
                                />

                            </div>
                           <label>Your room address</label><br/>
                            <div className="form-group">
                                <input type="text" className="form-control" 
                                    {...register("address", { required: "required" })}
                                />

                            </div>
                            <label>Upload room pic</label><br/>
                            <div className="form-group ">
                                <input type="file" className="form-control"  accept="image/*"
                                   onChange={onFileChange}
                                />

                            </div>
                            {/* <div className="form-group py-2">
                                                    <label htmlFor="files" className="form-control">Profile pic</label>
                                                    <input id="files" type="file" defaultValue="Upload Pic" className="form-control" accept="image/*" style={{ visibility: "hidden" }}
                                                        onChange={onFileChange}
                                                    />
                                                </div> */}
                            <div class="container-login100-form-btn p-t-25">
                                <button class="login100-form-btn">
                                    Add House
                                </button>
                            </div>


                            
                        </form>
                    </div>
                </div>
            </div>
             
        :""}

       
        </>
         


    )
  }
export default Addroom
