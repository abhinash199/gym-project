import React, { useState, useEffect, useContext } from 'react'
const MYPOST_API = "http://localhost:4001/mypost/";
import { UserContext } from "../App";
import { useForm } from "react-hook-form";
import { Card } from "react-bootstrap";
import { Link } from "react-router-dom"
import "./myprofile.css";
import {useParams} from 'react-router-dom'
import { Button } from 'react-bootstrap';
function MyProfile() {
   
   
    const [myprofile, setmyprofile] = useState([]);
    const { state, dispatch } = useContext(UserContext);
          
    const [Success, setSuccess] = useState(false)
    const [isSuccessfullySubmitted, setIsSuccessfullySubmitted] = useState(false);
    const [selectedFile, setselectedFile] = useState("");
    const { register, handleSubmit } = useForm();
    const [updateclick, setupdateclick] = useState(false);
    const [cancelClick, setCancelclick] = useState(false);

    //handle cancelClick
    const handleCancelclick = event => {
        setCancelclick(false);
        setupdateclick(false);
    }
    const onSubmit = (data) => {
        const { fullName, empid, gender, favCricketer, favCricketTeam, favIPL, date, freetime, goodtime, excitedAbout, food, skill, place, movies } = data;
    }
    useEffect(() => {
        fetch(
          `${MYPOST_API}${id}`,
            {
                method: "GET"
            }
        )
            .then(res => res.json())
            .then(response => {
                console.log("mypost", response.data);
                setmyprofile(response.data);
            })
            .catch(error => console.log(error));
    }, [])

    var id=state._id;
    console.log("id=",id);

    return (
        <>
            {
                console.log("statein profile", state)
            }
            {state ?
                <div className="container content">
                    <div className="row profile">
                        <div className="col-md-3">
                            <div className="profile-sidebar">
                                <div className="profile-userpic">




                                </div>

                                <div className="profile-usertitle">





                                </div>
                                <div className="profile-usermenu sidebar-sticky">
                                    <ul className="nav flex-column">
                                        <li className="active nav-item">
                                            <a href="#" className="nav-link active">
                                                <i className="fa fa-home"></i>
                                                Overview </a>
                                        </li>
                                    </ul>
                                </div>

                            </div>

                        </div>
                        {
                            console.log(Success, isSuccessfullySubmitted)

                        }
                        <div className="col-md-9">
                            {isSuccessfullySubmitted && !Success &&


                                <div className="success">Email sent successfully</div>


                            }
                            <div className="profile-content">
                                <ul className="nav-tabs">
                                    <li className="nav-item">
                                        General Information
                                    </li>
                                </ul>
                                <div className="profile-tab">
                                    <div>

                                        <div className="row">
                                            <div className="col-md-6">
                                                <label>firstname:</label>
                                            </div>
                                            {updateclick ?
                                                <div className="col-md-6" py-1>

                                                    <input type="text" name="favCricketer" className="form-control"
                                                        defaultValue={state.firstname}
                                                        {...register("firstname")}
                                                    />
                                                </div> :
                                                <div className="col-md-6">
                                                    <p>{state.firstname}</p>
                                                </div>
                                            }


                                        </div>

                                        <div className="row">
                                            <div className="col-md-6">
                                                <label>Lastname:</label>
                                            </div>
                                            {updateclick ?
                                                <div className="col-md-6" py-1>
                                                    <input type="text" name="favCricketer" defaultValue={state.lastname} className="form-control"
                                                        {...register("empid")}
                                                    />
                                                </div> :
                                                <div className="col-md-6">
                                                    <p>{state.lastname}</p>
                                                </div>
                                            }


                                        </div>

                                        <div className="row">
                                            <div className="col-md-6">
                                                <label>Phone No:</label>
                                            </div>
                                            {updateclick ?
                                                <div className="col-md-6" py-1>
                                                    <input type="text" name="favCricketer" defaultValue={state.phone} className="form-control"
                                                        {...register("phone")}
                                                    />
                                                </div> :
                                                <div className="col-md-6">
                                                    <p>{state.phone}</p>
                                                </div>
                                            }


                                        </div>

                                        <div className="row">
                                            <div className="col-md-6">
                                                <label>Gender:</label>
                                            </div>
                                            {updateclick ?
                                                <div className="col-md-6 py-1">
                                                    <select type="select" className="form-control" name="gender"
                                                        {...register("gender", { required: true })}
                                                    >
                                                        <option value="Male">Male</option>
                                                        <option value="Female">Female</option>

                                                    </select>
                                                </div> :
                                                <div className="col-md-6">
                                                    <p></p>
                                                </div>
                                            }
                                        </div>


                                        <div>
                                            {!updateclick ? <Button onClick={(e) => setupdateclick(true)}>Edit</Button> : ''}

                                            {updateclick ?
                                                <Button variant="success" onClick={handleSubmit(onSubmit)} style={{ margin: "10px" }}>Save</Button> : ''}
                                            {updateclick ? <Button variant="danger" onClick={(e) => handleCancelclick(e)}>Cancel</Button>
                                                : ''}
                                        </div>



                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> : ''
                //   <div className="nodata">No Data Found!</div>
            }

            <div>
                <h2>My Post</h2>
                <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top" src="holder.js/100px180" />
                    <Card.Body>
                        <Card.Title>Card Title</Card.Title>
                        <Card.Text>
                            Some quick example text to build on the card title and make up the bulk of
                            the card's content.
                        </Card.Text>
                        <Button variant="primary">Go somewhere</Button>
                    </Card.Body>
                </Card>
            </div>
        </>
    )
}

export default MyProfile
