import React,{useState,useContext} from 'react'
import RoomDetail from "./RoomDetail";
const RESET_API = "http://localhost:4001/reset";

import { Button } from 'react-bootstrap';
import { Link, useHistory } from "react-router-dom";
function Reset() {
   ;
    const history=useHistory();
    
    const [email, setEmail] = useState('');
   
     const ResetPassword = (e) => {
           e.preventDefault();
          
       fetch(RESET_API,{
            method:"post",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify({
               
                email
            })
        }).then(res=>res.json())
        .then(data=>{
           
           if(data.error){
              alert("invalid")
           }
           else{
              
             
                window.alert("reset successfull");
                history.push("/signin");
               
           }
        }).catch(err=>{
            console.log(err)
        })
           
       
      
    
    }
    return (

        <div class="login-form">
    <form>
      <h1>Reset Password</h1>
      <div class="form-group">
        <input type="email" name="email" value={email} placeholder="E-mail Address"onChange={(e)=>setEmail(e.target.value)} required/>
        <span class="input-icon"><i class="fa fa-envelope"></i></span>
      </div>
          
      <button class="login-btn" onClick={ResetPassword}>Reset</button>      
     
      
      
    </form>
  </div>
        // <div>
                  
        // <form>

        //     <div className="container"style={{width:"500px",height:"200px",justifyContent:'center',marginTop:"80px",border:"1px solid black",background:"red"}}>
        //     <h3 style={{color:"#fff",textAlign:"center"}}>Sign</h3>
        //     <div className="form-group">
        //       <input type="email" placeholder="email" className="form-control" value={email}
        //       onChange={(e)=>setEmail(e.target.value)}
        //       />
        //       </div>
        //        <div className="form-group">
        //       <input type="email" placeholder="password" className="form-control" value={password}
        //       onChange={(e)=>setPassword(e.target.value)}
        //       />
        //       </div>
        //        <Button type="submit"  variant="success"onClick={LoginUser}>Login</Button>
        //        <a href="/signup">Create an account</a>
        //     </div>
        //     </form>
        // </div>
    )
}

export default Reset
