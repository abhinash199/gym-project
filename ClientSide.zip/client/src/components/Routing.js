import React from 'react'
import { Route, Router, Switch, useHistory } from 'react-router'
import SideNavPage from '/Header'
import Header from 'Header'
import Home from './components/Home'
import Signup from './components/Signup'
import 'bootstrap/dist/css/bootstrap.min.css';
import Profile from './components/Profile';
import Addroom from "./components/Addroom";
import RoomDetail from "./components/RoomDetail";
import Detail from "./components/Detail";
import MemberDetail from './components/member-detail';
import Signin from './components/Signin';

import UserProfile from "./components/UserProfile"
import MyProfile from './components/MyProfile';
import { BrowserRouter } from "react-router-dom";
import  { useEffect, createContext, useContext, useReducer } from 'react';
import { reducer, initialState } from "./reducer/userReducer";
import Mypost from './components/Mypost'
import About from './About'
const Routing = () => {
    const history = useHistory()
    const { state, dispatch } = useContext(UserContext)
    useEffect(() => {
      const user = JSON.parse(localStorage.getItem("user"))
      console.log("user", user)
      if (user) {
        dispatch({ type: "USER", payload: user })
        history.push('/profile');
      }
    }, [])
    return (
      <>
  
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/signup" component={Signup} />
          <Route path="/signin" component={Signin} />
          <Route exact path="/profile" component={Profile} />
          <Route exact path="/profile/my-account" component={MyProfile} />
          <Route exact path="/add-room" component={Addroom} />
          <Route exact path="/profile/room-detail" component={RoomDetail} />
          <Route path="/profile/detail" component={Detail} />
          <Route path="/about" component={About} />
          <Route exact path="/profile/:userid">
            <UserProfile />
          </Route>
          <Route exact path="/mypost/:stateid">
            <Mypost />
          </Route>
        </Switch>
      </>
    )
  }
export default Routing
