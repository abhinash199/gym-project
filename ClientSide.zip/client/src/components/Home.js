import React,{useContext}from 'react'
import { Navbar, Nav, Container, Button, Carousel, CardGroup, Card } from "react-bootstrap";
import home from "../home.jfif";
import search from "../search.jfif";
import gallery from "../gallery2.jfif";
import about from "../about.jfif";
import room from "../room.jfif";
 import {UserContext} from "../App";
 import {Link} from "react-router-dom";
function Home() {
  const {state,dispatch} = useContext(UserContext);
    return (
        <div>
            <>
             <Carousel fade>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://dyimg1.realestateindia.com/proj_images/project31378/proj_header_image-31378-770x400.jpg"
            alt="First slide"
          />

        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://dyimg1.realestateindia.com/proj_images/project31378/proj_header_image-31378-770x400.jpg"
            alt="Second slide"
          />


        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://dyimg1.realestateindia.com/proj_images/project31378/proj_header_image-31378-770x400.jpg"
            alt="Third slide"
          />


        </Carousel.Item>
      </Carousel>
      <section className="section-btn">
        <div className="section-inner ourclubs">
          <img src={room} alt="room" style={{width:"200px",height:"200px",float:"left",margin:"20px",paddingLeft:"20px"}}/>
          <h2>Looking for room</h2>
          <p>Push your fitness further with our mix of facilities and we'll support you with advice on new and better ways to train.</p>
          <p className="btn-default"><Link to= {state?"/profile/room-detail":"/signin"}>Click Here</Link></p>

        </div>
      </section>
      <section className="section w-100">
        <CardGroup>
          <Card className="cardhover">

            <Card.Body>
              <Card.Img className="image" src={home} />
              <Card.Title className="title">Sell/Rent Your House</Card.Title>
              <Card.Text>
                Now you can digitalise your house
              </Card.Text>
            </Card.Body>

            <Card.Footer>
              <Link to={state?"/add-room":"/signin"}>
                <small className="text-muted">Post your House -&gt;</small>
              </Link>
            </Card.Footer>

          </Card>
          <Card className="cardhover">

            <Card.Body>
              <Card.Img className="image" src={search} />
              <Card.Title className="title">Find room near you</Card.Title>
              <Card.Text>
                Now you can easily search room near you
              </Card.Text>
            </Card.Body>
            <Card.Footer>
              <Link to={state?"/profile/room-detail":"/signin"}>
                <small className="text-muted">Search for room -&gt;</small>
              </Link>
            </Card.Footer>
          </Card>
          <Card className="cardhover">

            <Card.Body>
              <Card.Img className="image" src={gallery} />
              <Card.Title className="title">Happy Moments</Card.Title>
              <Card.Text>
                Here you can see the photos of happy moments
              </Card.Text>
            </Card.Body>
            <Card.Footer>
              <a href="#">
                <small className="text-muted">Click to view -&gt;</small>
              </a>
            </Card.Footer>
          </Card>
          <Card className="cardhover">

            <Card.Body>
              <Card.Img className="image" src={about} />
              <Card.Title className="title">Know about more</Card.Title>
              <Card.Text>
                From here we can get more info about this website
              </Card.Text>
            </Card.Body>
            <Card.Footer>
              <a href="#">
                <small className="text-muted">Need more info -&gt;</small>
              </a>
            </Card.Footer>
          </Card>
        </CardGroup>
      </section>
    </>
        </div>
    )
}

export default Home
