import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom';
const MYPOST_API = "http://localhost:4001/mypost/";
const DELETE_API = "http://localhost:4001/deletepost/";
import { Card, Button ,Modal} from "react-bootstrap";
import { useForm } from "react-hook-form";
const MEMBERS_IMAGE_URL = "http://localhost:4001/";
//import DeleteIcon from '@mui/icons-material/Delete';
function Mypost() {
    const { stateid } = useParams();
    const [editid, seteditid] = useState("")
    const [mypost, setmypost] = useState();
    const [updateclick, setupdateclick] = useState(false);
    const { register, handleSubmit, formState: { errors } } = useForm();
    const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

    console.log("userid", stateid);

    const deletePost = (postid) => {
        console.log("postid", postid);
        fetch(`${DELETE_API}${postid}`, {
            method: "delete",
            headers: {
                Authorization: "Bearer " + localStorage.getItem("jwt")
            }
        }).then(() => {
            setmypost(

                mypost.filter((val) => {
                    return val._id == !postid;
                })

            )
            window.alert("your post is deleted")
            window.location.reload();
        })

    }
    const onFileChange = event => {
        const file = event.target.files[0];
        setselectedFile(file);
    };
    const onSubmit =  (data) => {
        let fData = new FormData();
        fData.append(editid);
        console.log("modal data",fData);
        
        const requestOptions = {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        };
        fetch(`${UPDATE_API}${2}`, requestOptions)
            .then(response => response.json())
            .then(data => setPostId(data.id));
    }

    const fetchMypost = async () => {
        try {
            const res = await fetch(`${MYPOST_API}${stateid}`, {
                method: "GET",
                headers: {
                    "Authorization": "Bearer " + localStorage.getItem("jwt")
                }

            });
            const data = await res.json();

            setmypost(data.mypost)
            console.log("mypostabhi", data)


        } catch (err) {
            console.log(err);
        }
    }
    useEffect(() => {
        fetchMypost();
    }, [])




    return (
<>
        {

            console.log("len", mypost ? mypost : ""),
            mypost== undefined ? <h1>null</h1> : mypost.map((item) => (

                <>
                   
                        <button onClick={() => deletePost(item._id)}>Delete</button>
                        <button onClick={handleShow}
                        
                        >Edit</button>
                        
                   
                    <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
         
        <Modal.Header closeButton>
          <Modal.Title>Edit Detail{item._id}</Modal.Title>
        </Modal.Header>
        <form onSubmit={handleSubmit(onSubmit)}  encType="multipart/form-data">
        <Modal.Body>
        
        <div className="form-group py-2">
                                <input type="number" className="form-control" placeholder="Enter Plot No" defaultValue={item.plotno}
                                    {...register("plotno", { required: "required" })}
                                />
                             
                            </div>
                              
                            <div className="form-group py-2">
                                <select type="select" className="form-control" name="bhk" defaultValue={item.bhk}
                                                        {...register("bhk", { required: true })}
                                                   >
                                                        <option>1BHK</option>
                                                        <option>2BHK</option>
                                                        <option>3BHK</option>
                                                        <option>Single room</option>
                                                  </select>

                            </div>
                            <div className="form-group py-2">
                                <select type="select" className="form-control" name="status"defaultValue={item.status}
                                                        {...register("status", { required: true })}
                                                   >
                                                        <option value="Empty">Empty</option>
                                                        <option value="Booked">Booked</option>
                                                      
                                                  </select>

                            </div>
                            <div className="form-group py-2">
                                <input type="number" className="form-control" placeholder="price"defaultValue={item.price}
                                    {...register("price", { required: "required" })}
                                />

                            </div>
                            <div className="form-group py-2">
                                <select type="select" className="form-control" name="roomtype"defaultValue={item.roomtype}
                                                        {...register("roomtype", { required: true })}
                                                   >
                                                        <option>Room Type</option>
                                                        <option>New</option>
                                                        <option>0-1 year old</option>
                                                        <option>1-2 year old</option>
                                                        <option>2-3 year old </option>
                                                         <option>more than 3 year old </option>
                                                  </select>

                            </div>
                            <div className="form-group py-2">
                                <input type="text" className="form-control" placeholder="Your Home Address" defaultValue={item.address}
                                    {...register("address", { required: "required" })}
                                />

                            </div>
                            {/* <div className="form-group py-2">
                                <input type="file" className="form-control" placeholder="Your Home Address" accept="image/*"
                                   onChange={onFileChange}
                                />

                            </div> */}
         
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button type="submit" variant="primary">save</Button>
         
        </Modal.Footer>
        </form>
      </Modal>
                </>
            ))
           
       }
 
           
       
</>
    )
}






export default Mypost

