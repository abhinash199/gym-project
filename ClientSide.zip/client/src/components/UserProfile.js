import React,{useEffect,useState,useContext} from 'react'
import {UserContext} from "../App"
import {useParams} from 'react-router-dom'
const OTHERUSER_API = "http://localhost:4001/user/";
function UserProfile() {
     const {state,dispatch} = useContext(UserContext);
     const [userProfile,setProfile] = useState([]);
    const {userid} = useParams();
      console.log("userid",userid);

      const fetchUser=async()=>{
        try{
            const res=await fetch(`${OTHERUSER_API}${userid}`,{
                method:"GET",
                headers:{
                    "Authorization":"Bearer "+localStorage.getItem("jwt")
                }
           
            });
            const data=await res.json();
            setProfile(data)
            console.log(data)
         }catch(err){
    console.log(err);
         }
      }
     useEffect(()=>{
      fetchUser();
    },[])
    return (
        <div>

        {
            console.log("userprofile",userProfile),
        userProfile===undefined?<h2>Loading</h2>:userProfile.map((items)=>(
            <>
            <h2>{items.firstname}</h2>
            <h2>{items.lastname}</h2>
            <h2>{items.phone}</h2>
            </>
        ))}
        </div>
    )
}

export default UserProfile
