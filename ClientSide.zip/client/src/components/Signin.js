import React,{useState,useContext} from 'react'
import RoomDetail from "./RoomDetail";
const SIGNIN_API = "http://localhost:4001/signin";
import {UserContext} from "../App"
import { Button } from 'react-bootstrap';
import { Link, useHistory } from "react-router-dom";
function Signin() {
   ;
    const history=useHistory();
     const {state,dispatch} = useContext(UserContext);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
     const LoginUser = (e) => {
           e.preventDefault();
          
       fetch(SIGNIN_API,{
            method:"post",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify({
                password,
                email
            })
        }).then(res=>res.json())
        .then(data=>{
            console.log(data)
           if(data.error){
              alert("invalid")
           }
           else{
               localStorage.setItem("jwt",data.token)
               localStorage.setItem("user",JSON.stringify(data.user))
               dispatch({type:"USER",payload:data.user})
                window.alert("Signin successfull");
                history.push("/");
               
           }
        }).catch(err=>{
            console.log(err)
        })
           
       
      
    
    }
    return (

        <div class="login-form">
    <form>
      <h1>Login</h1>
      <div class="form-group">
        <input type="email" name="email" value={email} placeholder="E-mail Address"onChange={(e)=>setEmail(e.target.value)} required/>
        <span class="input-icon"><i class="fa fa-envelope"></i></span>
      </div>
      <div class="form-group">
        <input type="password" name="psw" placeholder="Password"  onChange={(e)=>setPassword(e.target.value)} value={password} required/>
        <span class="input-icon"><i class="fa fa-lock"></i></span>
      </div>      
      <button class="login-btn" onClick={LoginUser}>Login</button>      
      <a class="reset-psw" href="/reset">Forgot your password?</a>
      
      <p>New User?<a style={{color:"blue"}} href="/signup">Signup</a></p>
      
      
    </form>
  </div>
        // <div>
                  
        // <form>

        //     <div className="container"style={{width:"500px",height:"200px",justifyContent:'center',marginTop:"80px",border:"1px solid black",background:"red"}}>
        //     <h3 style={{color:"#fff",textAlign:"center"}}>Sign</h3>
        //     <div className="form-group">
        //       <input type="email" placeholder="email" className="form-control" value={email}
        //       onChange={(e)=>setEmail(e.target.value)}
        //       />
        //       </div>
        //        <div className="form-group">
        //       <input type="email" placeholder="password" className="form-control" value={password}
        //       onChange={(e)=>setPassword(e.target.value)}
        //       />
        //       </div>
        //        <Button type="submit"  variant="success"onClick={LoginUser}>Login</Button>
        //        <a href="/signup">Create an account</a>
        //     </div>
        //     </form>
        // </div>
    )
}

export default Signin
