import React from 'react'

function Detail(props) {
    console.log(props);
    return (
        <div>
           {
               props.data.map((i)=>(
                   <h2>{i.roomtype}</h2>
               ))
           }
        </div>
    )
}

export default Detail
