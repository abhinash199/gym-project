import React, { useEffect, useState, useContext } from 'react';
const Detail_API = "http://localhost:4001/profile/room-detail";
import Pagination from "./Pagination";
import { Link } from "react-router-dom";
import "./roomdetail.css";
import { Card, Form, Navbar, Container, Nav, CardGroup, Dropdown } from "react-bootstrap";
import { UserContext } from "../App";
import MyProfile from './MyProfile';
import { CardFooter } from 'reactstrap';

const MEMBERS_IMAGE_URL = "http://localhost:4001/";


function RoomDetail() {
    const [detail, setdetail] = useState();
    const [filteredData, setFilteredData] = useState(detail);
    const { state, dispatch } = useContext(UserContext);
    const [showPerPage, setshowPerPage] = useState(10);
    const [pagination, setpagination] = useState({
        start: 0,
        end: showPerPage,
    })

    const gedetail = async () => {
        try {
            const res = await fetch(Detail_API, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json"
                }

            });
            const data = await res.json();
            setdetail(data.data)
            setFilteredData(data.data);
            console.log(data)
        } catch (err) {
            console.log(err);
        }
    }

    useEffect(() => {
        gedetail();

    }, [])
    const handleSearch = (event) => {
        if (event.target.value == "Available") {
            const result = detail.filter((data) => {
                return data.status == "Available"
            });
            console.log("result", result);
            setFilteredData(result);
        }


    }
    const handleSearch2 = (event) => {
        if (event.target.value == "Booked") {
            const result = detail.filter((data) => {
                return data.status == "Booked"
            });
            setFilteredData(result);
        }


    }
    const handleSearch3 = (event) => {
        if (event.target.value == "All") {
            const result = detail.filter((data) => {
                return data
            });
            setFilteredData(result);
        }


    }
    //    const find2data=()=>{
    //     if(e.target.value=="Booked"){
    //     const filteredData= detail.data.filter((data)=>{
    //             return data.status=="Booked"
    //         })
    //         setfilterdata(filteredData)
    //     }

    // }
    const onPaginationChange = (start, end) => {
        setpagination({
            start: start,
            end: end
        })
    }
    return (
        <>
            <div>
            

                  
                <div style={{ display: "inline-block", height: "100px" ,float:"right",margin:"30px",marginTop:"80px"}}>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="Available" onChange={(event) => handleSearch(event)} />
                        <label class="form-check-label" for="exampleRadios1">
                            Available
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="Booked" onChange={(event) => handleSearch2(event)} />
                        <label class="form-check-label" for="exampleRadios2">
                            Booked
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="All" onChange={(event) => handleSearch3(event)} />
                        <label class="form-check-label" for="exampleRadios2">
                            All
                        </label>
                    </div>
                </div>
                {/* <div>
                <Form.Select aria-label="Default select example" >
                    <option>Open this select menu</option>
                    <option value="Empty">Empty</option>
                    <option  value="Booked">Booked</option>
                   
                </Form.Select>
            </div> */}
                <div>
                    {
                        console.log("filter", filteredData),
                        filteredData === undefined ? <h3>Loading</h3> : filteredData.slice(pagination.start, pagination.end).map((i) => {
                            return (
                                <>
                                    <CardGroup className="mycardgroup" style={{ width: "400px", display: "inline-block",marginTop:"75px" }}>
                                        <Card>
                                            <Card.Header><img style={{ width: "80px", height: "80px" }} src={MEMBERS_IMAGE_URL + i.imageName} />
                                                <div style={{ color: "red", display: "inline-block", marginRight: "20px", float: "right" }}>

                                                    <h4>Rs.{i.price}</h4>
                                                    <h5 style={{ color: "blue" }}>{i.bhk}</h5>
                                                    <h5>{i.status === "Booked" ? <h5 style={{ color: "red" }}>Booked</h5> : <h5 style={{ color: "green" }}>Available</h5>}</h5>
                                                </div>
                                            </Card.Header>
                                            <Card.Body>

                                                <Card.Text>
                                                    <h6 style={{ color: "#0e68aa" }}>Room Condition: <small style={{ color: "#000" }}>{i.roomtype}</small></h6><br />
                                                    <h6 style={{ color: "#0e68aa" }}>Water: <small style={{ color: "#000" }}>{i.water}</small></h6><br />
                                                    <h6 style={{ color: "#0e68aa" }}>Category: <small style={{ color: "#000" }}>{i.category}</small></h6><br />
                                                    <h6 style={{ color: "#0e68aa" }}>Address: <small style={{ color: "#000" }}>{i.plotno},{i.address}</small></h6><br />

                                                </Card.Text>
                                                <Card.Footer className="ownerback">
                                                    <Link to={"/profile/" + i.postedid}> Get owner contact</Link>
                                                </Card.Footer>
                                            </Card.Body>

                                        </Card>
                                    </CardGroup>


                                </>
                            )
                        })









                    }
                </div>
                <Pagination showPerPage={showPerPage} onPaginationChange={onPaginationChange} />
            </div>

        </>
    )
}


export default RoomDetail
