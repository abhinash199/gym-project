const mongoose=require("mongoose");
const DB="mongodb+srv://abhi:abhinash@cluster0.xpnwy.mongodb.net/LifeCity?retryWrites=true&w=majority"
console.log(DB);
mongoose.connect(DB,{
    useNewUrlParser:true,
    useUnifiedTopology:true,
  
}).then(()=>{
    console.log("connection successful");
}).catch((err)=>console.log("no connect",err));
