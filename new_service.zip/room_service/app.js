const express=require("express");
const app=express();
const cors=require("cors");
const path = require('path');
app.use(cors());
const dotenv=require("dotenv");
dotenv.config({path:'./config.env'});
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
const userController = require('./controller/userController');
const port = process.env.PORT || '4001';
app.use(express.static(path.join(__dirname, 'public')));
app.post('/signup',userController.userSignup);
app.post('/signin',userController.userSignin);
app.post('/add-room',userController.Addroom);
app.post('/upload',userController.uploadImage);
app.get('/profile',userController.profiledata);
app.post('/reset',userController.reset)
app.get('/user/:id',userController.Other);

app.delete('/deletepost/:id',userController.deletePost);
app.get('/mypost/:id',userController.Mypost);
app.get('/profile/room-detail',userController.roomdetail)
app.listen(port, () => {
    console.log(`Listening to requests on http://localhost:${port}`);
  });